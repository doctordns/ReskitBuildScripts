﻿# Set Lab VM CPU Counts


Set-VM -Name DC1 -ProcessorCount 6 

Set-VM -Name SRV1, Srv2 -ProcessorCount 2

Set-VM -Name SQL2012 -ProcessorCount 6

Set-VM -Name DNS1, DNS1 -ProcessorCount 4

